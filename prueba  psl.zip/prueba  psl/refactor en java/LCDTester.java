package testLCD;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

public class LCDTester {

    static final String CADENA_FINAL = "0,0";
    static final String ESPACIO_VALIDO = "^([1-5]{1})$";
    static final String COMANDO_VALIDO = "^([1-9]|10),([0-9]+)$"; 
    public static void main(String[] args) {

        List<String> listaComando = new ArrayList<>();
        String espacio="";
        String comando="";
        Scanner sc = new Scanner(System.in); 
        
        do {
            System.out.print("Ingrege el espacio entre Digitos (entero de 0 a 5): ");
            espacio = sc.next();
        } while (!Pattern.matches(ESPACIO_VALIDO, espacio));

        do
        {
            System.out.print("Entrada: ");
            comando = sc.next();
            if(!CADENA_FINAL.equals(comando)) {
            	if(Pattern.matches(COMANDO_VALIDO, comando))
            		listaComando.add(comando);
            	else
            		System.out.println("\""+comando+"\" no es un comando v�lido.");
            }
        }while (!CADENA_FINAL.equals(comando)); 
        sc.close();

        
        ImpresorLCD impresorLCD = new ImpresorLCD();
        for(String s:listaComando) {
        	String[] parametros=s.split(",");
        	impresorLCD.imprimirNumero(Integer.parseInt(parametros[0]),parametros[1], Integer.parseInt(espacio));
        }
    }

}
