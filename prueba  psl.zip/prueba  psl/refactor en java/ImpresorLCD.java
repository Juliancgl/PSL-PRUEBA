package testLCD;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ImpresorLCD {

    private String[][] matrizImpr;
    private final Map<Integer,int[]> ptosFijos;
    private final Map<Integer,List<Integer>> segmentos;

    static final String CARACTER_VERTICAL = "|";
    static final String CARACTER_HORIZONTAL = "-";
    static final String POSICION_X = "X";
    static final String POSICION_Y = "Y";
    private int size;

    private int filas;
    private int columDig;
    private int totalColum;

    public ImpresorLCD() {
        this.ptosFijos=new HashMap<>();
        this.segmentos=new HashMap<Integer,List<Integer>>() {
		private static final long serialVersionUID = 1L;{
				 put(1,Arrays.asList(3,4));
		         put(2,Arrays.asList(5,3,6,2,7));
		         put(3,Arrays.asList(5,3,6,4,7));
		         put(4,Arrays.asList(1,6,3,4));
		         put(5,Arrays.asList(5,1,6,4,7));
		         put(6,Arrays.asList(5,1,6,2,7,4));
		         put(7,Arrays.asList(5,3,4));
		         put(8,Arrays.asList(1,2,3,4,5,6,7));
		         put(9,Arrays.asList(1,3,4,5,6,7));
		         put(0,Arrays.asList(1,2,3,4,5,7));
	        }};
    }

    /**
     *
     * M�todo encargado de a�adir una linea a la matriz de Impresi�n
     *
     * @param punto Punto Pivote
     * @param posFija Posicion Fija
     * @param caracter Caracter Segmento
     */    
    private void adicionarLinea(int[] punto, String posFija,
            String caracter) {

        if (POSICION_X.equalsIgnoreCase(posFija)){
        	
            for (int y = 1; y <= size; y++) 
            {
                int valor = punto[1] + y;
                this.matrizImpr[punto[0]][valor] = caracter;
            }
        }else{
        	
            for (int i = 1; i <= size; i++) 
            {
                int valor = punto[0] + i;
                this.matrizImpr[valor][punto[1]] = caracter;
            }
        }
    }

    /**
     *
     * M�todo encargado de imprimir un n�mero
     *
     * @param size Tama�o Segmento Digitos
     * @param numeroImp N�mero a Imprimir
     * @param espacio Espacio Entre digitos
     */    
    public void imprimirNumero(int size, String numeroImp, int espacio) 
    {
        int pivotX = 0;
        this.size = size;
        this.filas = (2 * size) + 3;
        this.columDig = size + 2;
        this.totalColum = (columDig * numeroImp.length()) + (espacio * numeroImp.length());
        
        final int[] digitos = numeroImp.chars()
        	    .map(x -> x - '0')
        	    .toArray();

        this.matrizImpr = new String[filas][totalColum];
        
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < totalColum; j++) {
                this.matrizImpr[i][j] = " ";
            }
        }

        for (int digito : digitos) {

            this.ptosFijos.put(1, new int[] { 0,pivotX});
            this.ptosFijos.put(2, new int[] { (filas/2),pivotX});
            this.ptosFijos.put(3, new int[] { (filas-1),pivotX});
            this.ptosFijos.put(4, new int[] { (columDig-1),(filas/2)+pivotX});
            this.ptosFijos.put(5, new int[] { 0,(columDig-1)+pivotX});

            pivotX = pivotX + this.columDig + espacio;

            for(Integer i:segmentos.get(digito)) 
            	adicionarLinea(getPtoFijo(i), (i<5)?POSICION_Y:POSICION_X, (i<5)?CARACTER_VERTICAL:CARACTER_HORIZONTAL);
        }

        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < totalColum; j++) 
                System.out.print(matrizImpr[i][j]);
            
            System.out.println();
        }
    }
    
    private int[] getPtoFijo(Integer i) {
    	if(i==1 || i==2 || i==4) 
    		return ptosFijos.get(i);
    	else if(i==3)
    		return ptosFijos.get(5);
    	else if(i==5)
    		return ptosFijos.get(1);
    	else if(i==6)
    		return ptosFijos.get(2);
    	else
    		return ptosFijos.get(3);
    }

}
