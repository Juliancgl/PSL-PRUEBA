﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace display_aplication
{
    class ImpresorLCD
    {
        #region Definicion of variables
        private string[,] matrizImpr;
        private Dictionary<int,int[]> ptosFijos;
        private Dictionary<int, int[]> segmentos;
        private int size;
        private int filas;
        private int columDig;
        private int totalColum;
        #endregion


        #region maker
        public ImpresorLCD(){
            ptosFijos = new Dictionary<int, int[]>();
            segmentos = new Dictionary<int, int[]>();
            segmentos.Add(1, new int[] { 3,4});
            segmentos.Add(2, new int[] { 5, 3, 6, 2, 7 });
            segmentos.Add(3, new int[] { 5, 3, 6, 4, 7 });
            segmentos.Add(4, new int[] { 1, 6, 3, 4 });
            segmentos.Add(5, new int[] { 5, 1, 6, 4, 7 });
            segmentos.Add(6, new int[] { 5, 1, 6, 2, 7, 4 });
            segmentos.Add(7, new int[] { 5, 3, 4 });
            segmentos.Add(8, new int[] { 1, 2, 3, 4, 5, 6, 7 });
            segmentos.Add(9, new int[] { 1, 3, 4, 5, 6, 7 });
            segmentos.Add(0, new int[] { 1, 2, 3, 4, 5, 7 });
        }
        #endregion

        #region methods
        /// <summary>
        /// Método encargado de añadir una linea a la matriz de Impresión
        /// </summary>
        /// <param name="punto">punto Punto Pivote</param>
        /// <param name="posFija">osFija Posicion Fija</param>
        /// <param name="caracter">caracter Caracter Segmento</param>
        private void adicionarLinea(int[] punto, string posFija,string caracter)
        {

            if (ConfigurationManager.AppSettings["POSICION_X"].ToString().Equals(posFija, StringComparison.InvariantCultureIgnoreCase))
            {
                for (int y = 1; y <= size; y++)
                {
                    int valor = punto[1] + y;
                    matrizImpr[punto[0],valor] = caracter;
                }
            }
            else
            {
                for (int i = 1; i <= size; i++)
                {
                    int valor = punto[0] + i;
                   matrizImpr[valor,punto[1]] = caracter;
                }
            }
        }

        /// <summary>
        ///  Método encargado de imprimir un número
        /// </summary>
        /// <param name="size">size Tamaño Segmento Digitos</param>
        /// <param name="numeroImp">numeroImp Número a Imprimir</param>
        /// <param name="espacio">espacio Espacio Entre digitos</param>
        public void imprimirNumero(int size, string numeroImp, int espacio)
        {
            int pivotX = 0;
            this.size = size;
            filas = (2 * size) + 3;
            columDig = size + 2;
            this.totalColum = (columDig * numeroImp.Length) + (espacio * numeroImp.Length);

            List<int> digitos = numeroImp.Select(c => Convert.ToInt32(c.ToString())).ToList();
            matrizImpr = new string[filas, totalColum];
            int[] arreglo1;
            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < totalColum; j++)
                {
                    this.matrizImpr[i, j] = " ";
                }
            }

            foreach (int digito in digitos)
            {
               ptosFijos.Clear();
               ptosFijos.Add(1, new int[] { 0, pivotX });
               ptosFijos.Add(2, new int[] { (filas / 2), pivotX });
               ptosFijos.Add(3, new int[] { (filas - 1), pivotX });
               ptosFijos.Add(4, new int[] { (columDig - 1), (filas / 2) + pivotX });
               ptosFijos.Add(5, new int[] { 0, (columDig - 1) + pivotX });

                pivotX = pivotX + this.columDig + espacio;

                segmentos.TryGetValue(digito, out arreglo1);
                foreach (int i in arreglo1)
                    adicionarLinea(getPtoFijo(i), (i < 5) ? ConfigurationManager.AppSettings["POSICION_Y"].ToString() : ConfigurationManager.AppSettings["POSICION_X"].ToString(), (i < 5) ? ConfigurationManager.AppSettings["CARACTER_VERTICAL"].ToString() : ConfigurationManager.AppSettings["CARACTER_HORIZONTAL"].ToString());
            }

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < totalColum; j++)
                    Console.Write(matrizImpr[i,j]);

                Console.WriteLine();
            }
    }

        /// <summary>
        /// obtiene el punto fijo
        /// </summary>
        /// <param name="i">posición del key</param>
        /// <returns></returns>
        private int[] getPtoFijo(int i)
        {
            int[] arreglo;
            if (i == 1 || i == 2 || i == 4)
                ptosFijos.TryGetValue(i,out arreglo);
            else if (i == 3)
                ptosFijos.TryGetValue(5, out arreglo);
            else if (i == 5)
                ptosFijos.TryGetValue(1, out arreglo);
            else if (i == 6)
                 ptosFijos.TryGetValue(2, out arreglo);
            else
                 ptosFijos.TryGetValue(3, out arreglo);

            return arreglo;
        }

        #endregion
    }
}
