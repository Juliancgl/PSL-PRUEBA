﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace display_aplication
{
    class Program
    {
        static void Main(string[] args)
        {
            string CADENA_FINAL = "0,0";
            string ESPACIO_VALIDO = "^([1-5]{1})$";
            string COMANDO_VALIDO = "^([1-9]|10),([0-9]+)$";
            List<String> listaComando = new List<String>();
            String espacio = "";
            String comando = "";

            Regex rgx = new Regex(ESPACIO_VALIDO);
            Regex rgx2 = new Regex(COMANDO_VALIDO);
            do
            {
                Console.Write("Ingrege el espacio entre Digitos (entero de 0 a 5):");
                espacio = Console.ReadLine();
            } while (!rgx.IsMatch(espacio));

            do
            {
                Console.Write("Entrada: ");
                comando = Console.ReadLine();
                if (!CADENA_FINAL.Equals(comando))
                {
                    if (rgx2.IsMatch(comando))
                        listaComando.Add(comando);
                    else
                        Console.WriteLine("\"" + comando + "\" no es un comando válido.");
                }
            } while (!CADENA_FINAL.Equals(comando));

            ImpresorLCD impresorLCD = new ImpresorLCD();
            foreach (string s in listaComando)
            {
                string[] parametros = s.Split(',');
                impresorLCD.imprimirNumero(Convert.ToInt32(parametros[0]), parametros[1], Convert.ToInt32(espacio));
            }
            Console.ReadLine();

        }
       
    }
}
